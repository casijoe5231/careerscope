<?php
$receivedVariable = $_GET["temp"];

echo "<h1>The option you selected is ".$receivedVariable." </h1>";
echo "You can use this value, as to perform calculations, or query a database with this in the where part, and thus display tables or other dropdown boxes."

?>