<?php
    session_start();

    if(!isset($_SESSION['user'])){
        header("location:../login.php");
    }

//Connection Code
$db="careerscope";
$servername = "localhost";
$username = "root";
$password = "oracle";

// Create connection
$conn=mysql_connect($servername,$username,$password);  // Make Connection
	mysql_select_db($db);                      // Select Database

// Check connection
if (!$conn) {
    die('Could not connect: ' . mysql_error());
}
//echo "Connected successfully";

//Connection Code ends

//php code to shift goals whose deadline has passed to the goals dead table
$time = date('Y-m-d');

$email=$_SESSION['user'][0];
$sql1="Select * from goal_list where email like '$email' and deadline < '$time'";
$res1=mysql_query($sql1);
$count=mysql_num_rows($res1);
//echo $count;
//$time = date('Y-m-d H:i:s');
$success_count = 0;
if($count)
{
	while($row1=mysql_fetch_array($res1))
	{
				//if($row1['goal_com']===100)
		//{
			//echo $row1['goal_com'];
			//echo 'hi';
			
			$sql2="Insert into goal_dead(title,email,goal_id,action_plan,deadline,frequency,goal_type,time_added,goal_com) values('$row1[0]','$row1[1]','$row1[2]','$row1[3]','$row1[4]','$row1[5]','$row1[6]','$row1[7]','$row1[11]')";
			$res2=mysql_query($sql2);
			
			$sql3="Delete from goal_list where goal_id ='$row1[2]'";
			$res3=mysql_query($sql3);
			$title = $row1['title'];
			if($res2 && $res3)
			{
				$success_count = $success_count + 1;
				//echo "<SCRIPT LANGUAGE='JavaScript'>alert('Goal $title has been Completed Successfully');window.location.href='sdp_evidence.php';</SCRIPT>";
			}
			
		//}
	}
	if($success_count < 2 && $success_count!=0)
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>alert('Goal $title Has Crossed its Deadline');window.location.href='sdp_dead.php';</SCRIPT>";

	}
	else
	{
		echo "<SCRIPT LANGUAGE='JavaScript'>alert('More than One Goal Has Crossed its Deadline');window.location.href='sdp_dead.php';</SCRIPT>";
	}
}

//code to shift goals whose deadline has passed to the  goal dead table ends here

?>
<html>
<head>
<!-- Favicon -->
    <link href="images/favicon.ico" rel="shortcut icon"/>
	
    <title>EYB | SDP</title>
      
<!--  CSS  -->
<link rel="stylesheet" type="text/css" href="css/logo.css">
    
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
    <link rel='stylesheet' id='camera-css'  href='../css/camera.css' type='text/css' media='all'>
    <link rel="stylesheet" type="text/css" href="../css/carousel.css">
    <link rel="stylesheet" type="text/css" href="../css/slicknav.css">
    <link rel="stylesheet" href="../css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main
    stylesheet"charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700|Open+Sans:700' rel='stylesheet'             type='text/css'>
    <!--css ends-->
<style>
.col-md-2 {
    margin:20px;
}
</style>
</head>
<body>

<!--header-->
<style>
.headerLine{
    position: relative;
    width: 102%;
    
    height:22%;
    background: url(../images/bgTop.jpg) center center no-repeat;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
}
</style>
<!--header starts-->
<div style="margin-bottom:20px;" id="home">
            <div class="headerLine">
                <div id="menuF" class="default" style="margin-bottom:30px;">
                    <div class="container">
                        <div class="row">
                            <div class="logo col-md-2">
                                <div>
                                    <a href="#">
                                        <img src="../images/byblogo.png" width="120" height="120">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-10">
                                    <div class="navmenu"style="text-align: center;">
                                        <ul id="menu">
                                        </ul>
                                   </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--   /Header     -->
<!-- NAme of user-->
<div class="container">

    <div style="padding:10px;" class="panel panel-default">
    <div class="row">
        <div class="col-sm-3">
            <h5>Welcome <?php echo $_SESSION['user'][1]; ?>,</h5>
        </div>
        <div class="col-sm-7">
            
        </div>
		<div class="col-sm-1">
                    <a class="btn btn-default btn-block" href="../newindex.php"><span class="glyphicon glyphicon-home"></a>
		</div>
        <div class="col-sm-1">
            <span><a class="btn btn-default" href="../logout.php">Logout</a></span>
        </div>
        
    </div>
</div>
</div>
<!-- Name of user ends-->
<!-- body starts here-->
<div class="row">
  <div class="col-md-2">
  	<div class="panel panel-default">
  <!--<div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_view.php" data-toggle="tooltip" title="View all the Existing Schedules created till date">View Schedule</a></h3>
  </div>-->
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_edit.php" target='_blank'data-toggle="tooltip" title="Edit Existing Schedules">View/ Edit Schedule</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_delete.php" data-toggle="tooltip" title="Delete Unwanted Tasks">Delete Schedule</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_evidence.php" data-toggle="tooltip" title="Submit Certificates for Tasks Achieved">Submit Evidence</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_history.php" data-toggle="tooltip" title="View history of Changes made">History Log</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_weeklyupdate.php" data-toggle="tooltip" title="Update your Goal tasks">Weekly Status Update</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_progressreport.php" data-toggle="tooltip" title="View the Goal Progress">Progress Bar</a></h3>
  </div>
  <div class="panel-heading">
    <h3 class="panel-title"><a href="sdp_dead.php" data-toggle="tooltip" title="Revive Goals that have Crossed Deadline">Revive Goal</a></h3>
  </div>
</div>
  </div>
 <style>
 .panel-heading:hover {
  background-color: #0c81f6 !important;
  color:white;
}
}
 </style>
  <div class="col-md-8">
  		<div class="jumbotron">
  <h1>Self-Development Plan</h1>
  <p>Set your own Targets!</p>
  <p><a class="btn btn-primary btn-lg" href="sdp_add_goal.php" role="button">Add a Goal</a></p>
</div>
<style>
.btn-primary:hover{
	background-color:#241e92;
}
}
</style>
<!-- Generated markup by the plugin -->
<div class="tooltip top" role="tooltip">
  <div class="tooltip-arrow"></div>
  <div class="tooltip-inner">
    Some tooltip text!
  </div>
</div>
</div>
<br>
<br>
<br>
<!-- body ends here-->
<!--  Footer  -->
<div class="row">
<div  class="lineBlack">
    <div class="container">
        <div class="row downLine">
            <div class="col-md-11 text-right">
            </div>
            <div class="col-md-5 text-left copy">
                <p>Copyright &copy; 2014 Build Your Brand. All Rights Reserved.</p>
            </div>
            <div class="col-md-5 text-right dm">
               <!-- <ul id="downMenu">
                    <li class="active"><a href="#home">Home</a>
                    </li>
                    <li><a href="#" target="blank">Link 1</a>
                    </li>
                    <li><a href="#" target="blank">Link 2</a>
                    </li>
                    <li><a href="#" target="blank">Link 3</a>
                    </li>
                </ul>-->
            </div>
        </div>
    </div>
</div>
</div>
<!--  End of Footer  -->
</body>
</html>
