 <?php
    session_start();
	include 'styles/theme-master.php';
	include '../connection.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Courses</title>
<link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
<link rel="stylesheet" type="text/css" href="styles/theme-style.css">
<link rel="stylesheet" type="text/css" href="styles/theme-master.css">
</head>
<body>
<div class="bg">
<div class="container">
<?php
// Call header function from theme-master.php
header_fn();
?>
<div class="content clearfix">

<br><h3 style="text-align:center;">This is a sample page for the Master Styleshhet to be used in CareerScope Project.

<br> All primary styles for this page are saved in theme-master.css(Do not add styles here)
<br> All other site specific styles are needed to be saved in theme-style.css</h3>

</div>

<?php
// Call footer function from theme-master.php
footer_fn();
?>
</div>
</div>

</body>
</html>